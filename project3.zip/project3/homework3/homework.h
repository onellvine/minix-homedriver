#ifndef __HOMEWORK_H
#define __HOMEWORK_H

/** The Homework, World! message. */
#define HOMEWORK_MESSAGE "Homework, World!\n"

#endif /* __HOMEWORK_H */
